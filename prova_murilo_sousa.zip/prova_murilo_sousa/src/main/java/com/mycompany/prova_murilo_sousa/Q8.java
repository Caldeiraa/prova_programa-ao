/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author m.sousa
 */
public class Q8 {
    public static void main(String[] args) throws IOException {
        DataInputStream dado = new DataInputStream(System.in);
        FileWriter arq = new FileWriter ("C:\\Users\\m.sousa\\Desktop\\murilo\\Categoria");
        PrintWriter gravarArq = new PrintWriter(arq);
        String s,nome,categoria;
        float peso;
        
        System.out.println("Digite o nome do lutador: ");
        nome = dado.readLine();
        
        System.out.println("Digite o peso do lutador: ");
        s = dado.readLine();
        peso = Float.parseFloat(s);
         gravarArq.println("Categoria");
        if(peso < 65){
            categoria = "pena";
             gravarArq.println(nome+" categoria peso: "+categoria);
        }else if(peso <=72){
            categoria = "leve";
            gravarArq.println(nome+" categoria peso: "+categoria);
        }else if(peso <=79){
            categoria = "legeiro";
            gravarArq.println(nome+" categoria peso: "+categoria);
        }else if(peso <=86){
            categoria = "meio medio";
            gravarArq.println(nome+" categoria peso: "+categoria);
        }else if(peso <=93){
            categoria = "medio";
            gravarArq.println(nome+" categoria peso: "+categoria);
        }else if(peso <=100){
            categoria = "meio pesado";
            gravarArq.println(nome+" categoria peso: "+categoria);
        }else if(peso>100){
            categoria = "pesado";
            gravarArq.println(nome+" categoria peso: "+categoria);
        }
         arq.close();
    }
}
