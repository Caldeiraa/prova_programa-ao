/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import javax.swing.JOptionPane;

/**
 *
 * @author m.sousa
 */
public class Q3 {
     public static void main(String[] args) {
         String s;
         int antecessor,sucessor, n1;
         s = JOptionPane.showInputDialog(null, "digite um numero inteiro:");
         n1 = Integer.parseInt(s);
         
         antecessor = n1 - 1;
         sucessor = n1 + 1;
         
         JOptionPane.showMessageDialog(null,"Antecessor de "+n1+" é "+antecessor+" e o sucessor é "+sucessor);
                 
                 
                 
         
     }
    
    
}
