/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q2 {
    public static void main(String[] args) throws IOException {
    
    DataInputStream dado = new DataInputStream(System.in);
    int cafe,expresso = 0,capuccino = 0,CafeL = 0,quantidade=0; 
    float vendidos = 0;
    String s;
    do{
    System.out.println("1- Café expresso");
    System.out.println("2- Café capuccino");
    System.out.println("3- Leite com café");
    System.out.println("4- Totalizar vendas");
    s = dado.readLine();
    cafe = Integer.parseInt(s);
    
    if(cafe == 1){
       vendidos = (float) (vendidos + 0.75);
         expresso++;
         quantidade++;
    }else if(cafe == 2){
            vendidos = (float) (vendidos + 1.00);
            capuccino++;
             quantidade++;
    }else if(cafe == 3){
            vendidos = (float) (vendidos + 1.25);
            CafeL++;
             quantidade++;
    }else if(cafe == 4){
            System.out.println("quantidade de café expresso vendido foi: "+expresso);
            System.out.println("quantidade de café expresso vendido foi: "+capuccino);
            System.out.println("quantidade de café expresso vendido foi: "+CafeL);
            System.out.println("quantidade total foi de: "+quantidade+" cafés vendidos, e o valor total foi de:"+vendidos+" reais.");
    }
    }while(cafe != 4);
   }
}
