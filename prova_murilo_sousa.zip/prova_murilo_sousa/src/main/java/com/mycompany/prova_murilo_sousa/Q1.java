/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q1 {
    public static void main(String[] args) throws IOException {
     DataInputStream dado = new DataInputStream(System.in);
        String s;
        int ano,mes,dia,dias = 0;
        try{
        System.out.print("Digite ano: ");
        s = dado.readLine();
        ano = Integer.parseInt(s);
        
        System.out.print("Digite mês: ");
        s = dado.readLine();
        mes = Integer.parseInt(s);
        
        System.out.print("Digite dia: ");
        s = dado.readLine();
        dia = Integer.parseInt(s);
        
       dias = (ano * 365)+(mes * 30)+(dias + dia);
       
       System.out.print(ano+" anos, "+mes+"meses e "+dia+" dias = "+dias+" dias.");
        }catch(NumberFormatException e){
            System.out.print("Somente Numeros!");
        }
}
}
