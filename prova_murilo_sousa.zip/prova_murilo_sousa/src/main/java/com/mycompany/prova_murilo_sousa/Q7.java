/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 *
 * @author m.sousa
 */
public class Q7 {
    public static void main(String[] args) throws IOException {
        FileWriter arq = new FileWriter ("C:\\Users\\m.sousa\\Desktop\\murilo\\tabuada");
        PrintWriter gravarArq = new PrintWriter(arq);
        DataInputStream dado = new DataInputStream (System.in);
        String s;
        int n,resultado;
        
        System.out.println("Digite um numero inteiro para a tabuada: ");
        s = dado.readLine();
        n = Integer.parseInt(s);
        
        gravarArq.println("tabuada");
        for(int i=0;i<10;i++){
            resultado= n * (i+1);
            gravarArq.println(resultado);
        }
        arq.close();
    }
    
}
