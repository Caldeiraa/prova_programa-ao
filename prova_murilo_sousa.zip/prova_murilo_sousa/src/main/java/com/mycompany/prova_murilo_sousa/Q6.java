/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q6 {
     public static void main(String[] args) throws IOException {
         DataInputStream dado = new DataInputStream(System.in);
         String nome,nomeF = null, filme;
         String [] pista = new String [5];
         System.out.print("Digite seu nome: ");
         nome = dado.readLine();
         
        System.out.println(nome+" digite o nome do filme:");
        filme = dado.readLine();
        
        for(int i=0;i<5;i++){
            System.out.println(nome+" digite a pista "+(i+1));
            pista[i] = dado.readLine();
        }
        
         System.out.println("======================================================");
         
         System.out.println("Digite seu nome: ");
         nome = dado.readLine();
         
        
         for(int i=0;i<5;i++){
            
                System.out.println(nome+" a pista "+(i+1)+" é: "+pista[i]);  
                System.out.println(nome+" qual o nome do filme? ");
                nomeF = dado.readLine();   
                if(nomeF == null ? filme == null : nomeF.equals(filme)){
                    System.out.println("acertou!");
                break;
                }
         }
         
    }
}
