/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prova_murilo_sousa;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author m.sousa
 */
public class Q4 {
     public static void main(String[] args) throws IOException {
         DataInputStream dado = new DataInputStream(System.in);
         int codigo, cogidoCo = 1234,senha,senhaCo=9999;
         String s; 
         
         do{
         System.out.print("Digite o codigo armazenado: ");
         s = dado.readLine();
         codigo = Integer.parseInt(s);
         
         if(codigo == cogidoCo){
             System.out.println("Usuario valido!");
             
             do{
             System.out.print("Digite sua senha: ");
             s = dado.readLine();
             senha = Integer.parseInt(s);
             if(senha == senhaCo){
                 System.out.println("Acesso liberado!");
             }
             }while(senha != senhaCo);
             
         }else if(codigo != cogidoCo){
             System.out.println("Usuario Invalido!");
         }
         }while(codigo != cogidoCo);
     }
}
